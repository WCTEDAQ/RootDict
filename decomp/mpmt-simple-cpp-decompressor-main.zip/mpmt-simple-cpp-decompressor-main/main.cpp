#include "wctedecompress.h"
#include <fstream>
#include <iostream>

/**
 * @brief Demo
 * 
 * In this demo, we read examples from exported
 * samples collected in true measurements.
 * As a result, a CSV file with decompressed/decoded
 * samples is written. Gives an example of decompressor
 * usage.
 */
int main(int argc, char *argv[]) {
    // create a decompressor object, use one to reuse LUT tables
    WCTEDecompress::WCTEWaveformDecompress decompressor;
    
    // open input and output files
    std::ofstream os("test2.csv");
    std::ifstream in("test2.bin");
    while (!in.eof()) {
        // read waveform header - number of bytes and numer of samples u32 little endian
        uint32_t l,samples;
        in.read(reinterpret_cast<char*>(&l),4);
        in.read(reinterpret_cast<char*>(&samples),4);
        std::cout << "len=" << l << " samples=" << samples <<  std::endl;
        if (l>0) {
            std::vector<uint8_t> vin;
            vin.resize(l);
            // read samples
            in.read(reinterpret_cast<char*>(vin.data()),l);
            // decode
            std::vector<int16_t> res = decompressor.decode(vin.data(),vin.size(),samples,1);
            // and save
            for (int i=0;i<res.size();i++) {
                if (i>0)
                    os << ",";
                os << res[i];
            }
            os << std::endl;
        }
    }
}

