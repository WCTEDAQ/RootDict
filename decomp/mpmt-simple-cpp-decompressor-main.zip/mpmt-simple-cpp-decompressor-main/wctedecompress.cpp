
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <stdint.h>
#include "wctedecompress.h"

using namespace std;

namespace WCTEDecompress {

    /**
     * @brief This is a bitstream reader that allows
     * to read arbitrary number of bits from datastream
     * (up to 32) as an uint32_t value
     */
    class BitReader
    {
    private:
        const unsigned char* data_in = nullptr;
        int data_size = 0;
        long data_pos = 0;
        uint32_t bitbuf = 0;
        int buf_size = 32;
        int valid = 0;

    public:
        BitReader(const unsigned char* data_in, int data_size);
        virtual ~BitReader() {};

        uint32_t readBits(int num_bits);
        uint32_t readByte() { return readBits(8); }

        int peek16bits();

        long getDataPos() { return data_pos; }
    };

    BitReader::BitReader(const unsigned char* data_in, int data_size)
    {
        this->data_in = data_in;
        this->data_size = data_size;
        data_pos = 0;
        bitbuf = 0;
        buf_size = 32;
        valid = 0;
    }

    uint32_t BitReader::readBits(int num_bits)
    {
        uint32_t val = 0;
        while (num_bits > 0) {
            if (valid == 0) { // bitbuf empty - read from input data
                if (data_pos >= data_size) {
                    cout << "ERROR: " << "BitReader: not enough bytes while reading bits" << endl;
                    //throw string("BitReader: not enough bytes while reading bits"); // in order to stop executing the program
                    return -1;  // program will continue, but wrong WAV values will be decoded/decompressed (but the following PACKET/TC headers can be decoded correctly)
                }
                bitbuf = data_in[data_pos++]; // read first byte
                valid = 8;
                for (int i = 0; i < 3; i++) { // read next three bytes
                    bitbuf <<= 8; // move bits up one byte
                    if (data_pos < data_size) { // read next byte if available
                        bitbuf |= data_in[data_pos++];
                        valid += 8;
                    }
                }
            }
            // read bits_to_read bits from bitbuf (most significant bits)
            int bits_to_read = (valid < num_bits) ? valid : num_bits;
            val = (val << bits_to_read) + ((bitbuf >> (buf_size - bits_to_read)));
            bitbuf <<= bits_to_read; // move bits in bitbuf left (remove read bits form bitbuf)
            //bitbuf &= (1 << buf_size) - 1;
            valid -= bits_to_read;
            num_bits -= bits_to_read;
        }

        return val;
    }

    int BitReader::peek16bits()
    {
        if (valid < 16) { // read more bytes to bitbuf
            int bytes_to_read = (int)((32-valid)/8);
            // there might be less than bytes_to_read bytes left in data_in - it does not have to be an error
            int num = data_size - data_pos;
            num = (num > bytes_to_read) ? bytes_to_read : num;
            if (num > 0) {
                int boffset = 24 - valid; 
                for (int i = 0; i < num; i++) {
                    bitbuf += (data_in[data_pos++] << boffset); // move read bytes left by boffset to aligh to the valid bits in bitbuf
                    valid += 8;
                    boffset -= 8;
                }
            }
        }

        return bitbuf >> 16;
    }


    // Base class for codebook decoders.
    class CBDecoder
    {
    public:
        virtual int decode(BitReader& br) = 0;
        virtual ~CBDecoder(){}
    };


    /**
     * @brief LUT-based codebook decoder (for normalized prefix codes). 
     * 
     * Optimized implementation with LUT for faster symbol decoding, i.e.:
     * for each codeword (given by sequence of bits B..B, known from the codebook):
     * each cell in LUT with indexes from B..B0..0 to B..B1..1 stores the symbol to be decoded as well as the actual number of bits to be read/removed from input bitstream.
     * Instead of reading successive bits from input stream and checking if the symbol can be decoded yet, 
     * 16 bit is peeked from input stream and the symbol is decoded in one LUT read/check followed by reading actual number of bits from input. 
     */
    class LUTDecoder : public CBDecoder
    {
    private:
        static const int lut_bitsize = 16;
        int decode_lut[1<<lut_bitsize][2] = {};
    public:
        static const int NONE = 0x00ffffff; // some value indicating that decoding was not successfull - any value different from valid symbols to be decoded!!! (in HK smbols are at most 12bit values)

        LUTDecoder(const vector<vector<int>>& codebook);

        int decode(BitReader& br);
    };

    LUTDecoder::LUTDecoder(const vector<vector<int>>& codebook)
    {
        // lut initialization
        for (int i = 0; i < (1 << lut_bitsize); i++) {
            decode_lut[i][0] = NONE; // there should be no such a symbol
            decode_lut[i][1] = lut_bitsize + 1; // there should be no such long codeword
        }
        // codebook[idx] contains: [symbol, code_len, code_val] 
        int num_symbols = codebook.size();
        for (int i = 0; i < num_symbols; i++) {
            int sym = codebook[i][0];
            int code_len = codebook[i][1];
            int code_val = codebook[i][2];
            if (code_len > lut_bitsize) {
                cout << "ERROR: " << "LUTDecoder: code_len=" << code_len << " while lut_bitsize=" << lut_bitsize << endl;
                //throw string("LUTDecoder: code_len greater than lut_bitsize"); // in order to stop executing the program
                exit(-1); // in order to stop executing the program (there is no point in continuing - BAD codebook)
            }
            int rest_bits = lut_bitsize - code_len;
            int lut_start = code_val << rest_bits; //inclusive; B..B0..0
            int lut_end = lut_start + (1 << rest_bits); //exclusive; B..B1..1 + 1
            for (int lut_idx = lut_start; lut_idx < lut_end; lut_idx++) {
                // all cell in the range contains the same symbol (and its code_len)
                decode_lut[lut_idx][0] = sym;
                decode_lut[lut_idx][1] = code_len;
            }
        }
    }

    int LUTDecoder::decode(BitReader& br)
    {
        unsigned int val16b = br.peek16bits();
        int sym = decode_lut[val16b][0];
        int code_len = decode_lut[val16b][1];
        // if sym == NONE -> something went wrong (maybe other decoding is needed at upper level?) so no bits are read from input;
        // otherwise: read code_len bits from input
        if (sym != NONE)
            br.readBits(code_len);
        return sym;
    }

    // codebook used for coding/decoding waveforms
    static const vector<vector<int>> code_book_4 = {
        {-9999, 8, 240}, 
        {-64, 13, 8178}, {-63, 13, 8179}, {-62, 13, 8180}, {-61, 12, 4056}, {-60, 12, 4057}, {-59, 12, 4058}, {-58, 12, 4059}, {-57, 12, 4060}, 
        {-56, 12, 4061}, {-55, 12, 4062}, {-54, 12, 4063}, {-53, 12, 4064}, {-52, 12, 4065}, {-51, 12, 4066}, {-50, 12, 4067}, {-49, 12, 4068}, 
        {-48, 12, 4069}, {-47, 12, 4070}, {-46, 12, 4071}, {-45, 12, 4072}, {-44, 12, 4073}, {-43, 12, 4074}, {-42, 12, 4075}, {-41, 12, 4076}, 
        {-40, 11, 1968}, {-39, 11, 1969}, {-38, 11, 1970}, {-37, 11, 1971}, {-36, 11, 1972}, {-35, 11, 1973}, {-34, 11, 1974}, {-33, 11, 1975}, 
        {-32, 11, 1976}, {-31, 11, 1977}, {-30, 11, 1978}, {-29, 11, 1979}, {-28, 11, 1980}, {-27, 11, 1981}, {-26, 11, 1982}, {-25, 11, 1983}, 
        {-24, 11, 1984}, {-23, 11, 1985}, {-22, 11, 1986}, {-21, 11, 1987}, {-20, 11, 1988}, {-19, 11, 1989}, {-18, 11, 1990}, {-17, 11, 1991}, 
        {-16, 11, 1992}, {-15, 11, 1993}, {-14, 11, 1994}, {-13, 11, 1995}, {-12, 11, 1996}, {-11, 11, 1997}, {-10, 11, 1998}, {-9, 11, 1999},  
        {-8, 11, 2000},  {-7, 11, 2001},  {-6, 11, 2002},  {-5, 11, 2003},  {-4, 10, 976},   {-3, 9, 484},    {-2, 7, 118},    {-1, 3, 6},      
        {0, 1, 0},       {1, 2, 2},       {2, 5, 28},      {3, 6, 58},      {4, 7, 119},     {5, 8, 241},     {6, 9, 485},     {7, 9, 486},     
        {8, 9, 487},     {9, 10, 977},    {10, 10, 978},   {11, 10, 979},   {12, 10, 980},   {13, 10, 981},   {14, 10, 982},   {15, 10, 983},
        {16, 11, 2004},  {17, 11, 2005},  {18, 11, 2006},  {19, 11, 2007},  {20, 11, 2008},  {21, 11, 2009},  {22, 11, 2010},  {23, 11, 2011},  
        {24, 11, 2012},  {25, 11, 2013},  {26, 11, 2014},  {27, 11, 2015},  {28, 11, 2016},  {29, 11, 2017},  {30, 11, 2018},  {31, 11, 2019},  
        {32, 11, 2020},  {33, 11, 2021},  {34, 11, 2022},  {35, 11, 2023},  {36, 11, 2024},  {37, 11, 2025},  {38, 11, 2026},  {39, 11, 2027},  
        {40, 12, 4077},  {41, 12, 4078},  {42, 12, 4079},  {43, 12, 4080},  {44, 12, 4081},  {45, 12, 4082},  {46, 12, 4083},  {47, 12, 4084},  
        {48, 12, 4085},  {49, 12, 4086},  {50, 12, 4087},  {51, 12, 4088},  {52, 13, 8181},  {53, 13, 8182},  {54, 13, 8183},  {55, 13, 8184},  
        {56, 13, 8185},  {57, 13, 8186},  {58, 13, 8187},  {59, 13, 8188},  {60, 13, 8189},  {61, 13, 8190},  {62, 14, 16382}, {63, 14, 16383}
    };

    WCTEDecompress::WCTEWaveformDecompress::WCTEWaveformDecompress()
    {
        decoder = new LUTDecoder(code_book_4);
    }

    WCTEDecompress::WCTEWaveformDecompress::~WCTEWaveformDecompress()
    {
        delete decoder;
    }

    vector<int16_t> WCTEDecompress::WCTEWaveformDecompress::decode(const unsigned char *data, int data_size, int num_samples, int compr_enable)
    {
        vector<int16_t> data_out(num_samples);
        if (compr_enable) {
            BitReader breader = BitReader(data, data_size);
            // first sample - direct value, 12 bits
            int16_t sample = (int16_t)(breader.readBits(12) << 4) >> 4;
            data_out[0] = sample;
            // next samples - differential value or ESC code followed by direct 12bit value
            for (int idx = 1; idx < num_samples; idx++) {
                int val = decoder->decode(breader);
                if (val == -9999) { // ESC code
                    sample = (int16_t)(breader.readBits(12) << 4) >> 4;
                    data_out[idx] = sample;
                }
                else { // differential value
                    data_out[idx] = data_out[idx - 1] + (int16_t)val;
                }
            }
            if (breader.getDataPos() < data_size)
                cout << "ERROR: " << "WAV decoding - to many bytes: data_size=" << data_size << ", br.pos=" << breader.getDataPos() << endl;
        }
        else {
            for (int idx = 0; idx < num_samples / 2; idx++) {
                // two samples on three bytes; samples are 'signed 12 bit'
                unsigned char b0 = data[3 * idx];
                unsigned char b1 = data[3 * idx + 1];
                unsigned char b2 = data[3 * idx + 2];
                int16_t sample1 = (int16_t)((b0 << 8) + b1) >> 4;
                int16_t sample2 = (int16_t)(((b1 << 8) + b2) << 4) >> 4;
                data_out[2 * idx] = sample1;
                data_out[2 * idx + 1] = sample2;
            }
            if (num_samples / 2 * 2 != num_samples) { 
                // odd number of samples - the last sample stored in two bytes
                int idx = num_samples / 2 * 3;
                unsigned char b0 = data[idx];
                unsigned char b1 = data[idx + 1];
                int16_t sample = (((int16_t)b0 << 8) + b1) >> 4;
                data_out[num_samples - 1] = sample;
            }
        }
        return data_out;
    }

}