#ifndef _wctedecompressH_
#define _wctedecompressH_

#include <vector>
#include <cstdint>

namespace WCTEDecompress{

    /**
     * @brief Forward declaration of base decoders class
     */
    class CBDecoder;

    /**
     * @brief This class is a wrapper to reference code of waveform decompressor.
     * Hides details of the implementation from user.
     */
    class WCTEWaveformDecompress{
        CBDecoder *decoder;
    public:
        /**
         * @brief Construct a new WCTEWaveformDecompress object, initializes
         * embedded LET based huffmann decoder
         */
        WCTEWaveformDecompress();
        /**
         * @brief Destroy the WCTEWaveformDecompress object
         * deallocated LUT decoder
         */
        ~WCTEWaveformDecompress();
        /**
         * @brief Decodes single waveform data, supports both compressed and uncompressed representation
         * 
         * This function is fully reentrant and thread safe.
         * 
         * @param data waveform data as bytes
         * @param data_size size of data
         * @param num_samples number of expected samples
         * @param compr_enable set to true if waveform is compressed, false if not
         * @return std::vector<int16_t> decoded samples as signed integers
         */
        std::vector<int16_t> decode(const unsigned char* data, int data_size, int num_samples, int compr_enable);
    };

};

#endif